import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:myapp/Home.dart' as Home; // Use an alias for Home.dart
import 'package:myapp/home.dart'; // Keep this import as is


// addded

List<CameraDescription>? cameras;
void main() async {
  // added also async
  WidgetsFlutterBinding.ensureInitialized();
  cameras = await availableCameras();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CCTV Security',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(), // Ensure this refers to the correct HomePage
    );
  }
}