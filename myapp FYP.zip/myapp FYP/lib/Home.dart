import 'package:flutter/material.dart';
import 'package:myapp/login.dart';
import 'package:myapp/Register.dart';
import 'custom_widgets.dart'; // Import custom widgets
import 'package:myapp/Home.dart';
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: <Widget>[
          // Left-hand side (LHS) - Background Image
          Expanded(
            flex: 1,
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/image123.jpg'), // Background image
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          // Right-hand side (RHS) - Buttons and Logo
          Expanded(
            flex: 1,
            child: Stack(
              children: <Widget>[
                // Centered Buttons and Text
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      CustomText(text: 'Welcome To', fontSize: 28),
                      CustomText(text: 'CCTV Security', fontSize: 28),
                      SizedBox(height: 40),
                      // Login Button
                      SizedBox(
                        width: 200, // Fixed width for both buttons
                        child: CustomButton(
                          text: 'Login',
                          onPressed: () =>
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginPage()),
                              ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // Register Button
                      SizedBox(
                        width: 200, // Fixed width for both buttons
                        child: CustomButton(
                          text: 'Register',
                          onPressed: () =>
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => RegisterPage()),
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Logo at the Top-Right Corner
                Positioned(
                  top: 20,
                  right: 20,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('assets/logo123.jpg'), // Logo image
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}