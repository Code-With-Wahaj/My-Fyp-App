import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;

class CameraDetectionWidget extends StatefulWidget {
  final int cameraIndex;

  const CameraDetectionWidget({Key? key, required this.cameraIndex}) : super(key: key);

  @override
  _CameraDetectionWidgetState createState() => _CameraDetectionWidgetState();
}

class _CameraDetectionWidgetState extends State<CameraDetectionWidget> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  late Interpreter _interpreter;
  bool _isModelLoaded = false;
  List<Map<String, dynamic>> _detections = [];
  bool _isProcessing = false;
  int _frameCount = 0;

  @override
  void initState() {
    super.initState();
    _initCamera();
    _loadModel();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      _controller = CameraController(
        cameras[widget.cameraIndex],
        ResolutionPreset.medium,
        enableAudio: false,
      );
      _initializeControllerFuture = _controller.initialize();
      await _initializeControllerFuture;
      _controller.startImageStream(_processCameraImage);
    } catch (e) {
      debugPrint('Camera error: $e');
    }
  }

  Future<void> _loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('best.tflite');
      _interpreter.allocateTensors();
      _isModelLoaded = true;
      debugPrint('Model loaded successfully');
    } catch (e) {
      debugPrint('Failed to load model: $e');
    }
  }

  void _processCameraImage(CameraImage image) async {
    if (!_isModelLoaded || _isProcessing) return;

    _frameCount++;
    if (_frameCount % 3 != 0) return; // Process every 3rd frame

    _isProcessing = true;

    try {
      final input = await _preprocessImage(image);
      final output = _runInference(input);
      final detections = _processOutput(output, image.width, image.height);

      setState(() {
        _detections = detections;
      });
    } catch (e) {
      debugPrint('Processing error: $e');
    } finally {
      _isProcessing = false;
    }
  }

  Future<List<double>> _preprocessImage(CameraImage image) async {
    final rgbImage = _convertCameraImage(image);
    final resized = img.copyResize(rgbImage, width: 640, height: 640);
    return _imageToNormalizedTensor(resized);
  }

  img.Image _convertCameraImage(CameraImage image) {
    if (image.format.group == ImageFormatGroup.yuv420) {
      return _convertYUV420toRGB(image);
    } else {
      return img.Image.fromBytes(
        image.width,
        image.height,
        image.planes[0].bytes,
        format: img.Format.rgba,
      );
    }
  }

  img.Image _convertYUV420toRGB(CameraImage image) {
    final width = image.width;
    final height = image.height;
    final yPlane = image.planes[0].bytes;
    final uPlane = image.planes[1].bytes;
    final vPlane = image.planes[2].bytes;
    final yRowStride = image.planes[0].bytesPerRow;
    final uvRowStride = image.planes[1].bytesPerRow;
    final uvPixelStride = image.planes[1].bytesPerPixel;

    final rgbImage = img.Image(width, height);

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        final int yIndex = y * yRowStride + x;
        final int uvIndex = (y ~/ 2) * uvRowStride + (x ~/ 2) * uvPixelStride!;

        final int yValue = yPlane[yIndex];
        final int uValue = uPlane[uvIndex] - 128;
        final int vValue = vPlane[uvIndex] - 128;

        final r = (yValue + 1.402 * vValue).clamp(0, 255).toInt();
        final g = (yValue - 0.344136 * uValue - 0.714136 * vValue).clamp(0, 255).toInt();
        final b = (yValue + 1.772 * uValue).clamp(0, 255).toInt();

        rgbImage.setPixelRgba(x, y, r, g, b);
      }
    }
    return rgbImage;
  }

  List<double> _imageToNormalizedTensor(img.Image image) {
    final input = List<double>.filled(640 * 640 * 3, 0);
    int pixelIndex = 0;

    for (int y = 0; y < 640; y++) {
      for (int x = 0; x < 640; x++) {
        final pixel = image.getPixel(x, y);
        input[pixelIndex++] = img.getRed(pixel) / 255.0;
        input[pixelIndex++] = img.getGreen(pixel) / 255.0;
        input[pixelIndex++] = img.getBlue(pixel) / 255.0;
      }
    }
    return input;
  }

  List<dynamic> _runInference(List<double> input) {
    final outputShape = _interpreter.getOutputTensor(0).shape;
    final output = List.filled(
        outputShape.reduce((a, b) => a * b),
        0
    ).reshape(outputShape);

    _interpreter.run(input, output);
    return output;
  }

  List<Map<String, dynamic>> _processOutput(List<dynamic> output, int imageWidth, int imageHeight) {
    final detections = <Map<String, dynamic>>[];
    final outputArray = output[0]; // Shape: [1, 84, 8400] for YOLOv8

    for (int i = 0; i < 8400; i++) {
      final confidence = outputArray[4][i];
      if (confidence > 0.5) { // Confidence threshold
        final classProbs = outputArray.sublist(5).map((list) => list[i]).toList();
        final maxProb = classProbs.reduce((a, b) => a > b ? a : b);
        final classId = classProbs.indexOf(maxProb);

        // Convert normalized coordinates to pixel coordinates
        final x = (outputArray[0][i] * imageWidth).toDouble();
        final y = (outputArray[1][i] * imageHeight).toDouble();
        final w = (outputArray[2][i] * imageWidth).toDouble();
        final h = (outputArray[3][i] * imageHeight).toDouble();

        detections.add({
          'class': classId,
          'confidence': confidence,
          'rect': Rect.fromLTWH(
            x - w/2, // Convert centerX to left
            y - h/2, // Convert centerY to top
            w,
            h,
          ),
        });
      }
    }
    return _nonMaxSuppression(detections);
  }

  List<Map<String, dynamic>> _nonMaxSuppression(List<Map<String, dynamic>> detections) {
    // Sort by confidence (highest first)
    detections.sort((a, b) => b['confidence'].compareTo(a['confidence']));

    final filteredDetections = <Map<String, dynamic>>[];

    while (detections.isNotEmpty) {
      // Take the detection with highest confidence
      final current = detections.removeAt(0);
      filteredDetections.add(current);

      // Remove overlapping detections
      detections.removeWhere((det) {
        final rect1 = current['rect'] as Rect;
        final rect2 = det['rect'] as Rect;
        return _calculateIOU(rect1, rect2) > 0.5; // IOU threshold
      });
    }

    return filteredDetections;
  }

  double _calculateIOU(Rect a, Rect b) {
    final intersection = a.intersect(b);
    final intersectionArea = intersection.width * intersection.height;
    final unionArea = a.width * a.height + b.width * b.height - intersectionArea;
    return intersectionArea / unionArea;
  }

  @override
  void dispose() {
    _controller.dispose();
    _interpreter.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        FutureBuilder<void>(
          future: _initializeControllerFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return CameraPreview(_controller);
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          },
        ),
        CustomPaint(
          painter: DetectionPainter(_detections),
          child: Container(),
        ),
      ],
    );
  }
}

class DetectionPainter extends CustomPainter {
  final List<Map<String, dynamic>> detections;

  DetectionPainter(this.detections);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
    );

    for (final detection in detections) {
      final rect = detection['rect'] as Rect;
      canvas.drawRect(rect, paint);

      textPainter.text = TextSpan(
        text: 'Class ${detection['class']} ${(detection['confidence'] * 100).toStringAsFixed(1)}%',
        style: const TextStyle(color: Colors.red, fontSize: 14),
      );
      textPainter.layout();
      textPainter.paint(canvas, Offset(rect.left, rect.top - 20));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}